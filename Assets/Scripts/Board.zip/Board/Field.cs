﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Field : MonoBehaviour
{
    public delegate void OnStep();
    public OnStep onStep;
    public bool isWhite;
    private GameManager manager;
    public ChessPiece piece;

    public void Start()
    {
        manager = GameObject.Find("GameManager").GetComponent<GameManager>();

        if ((int)(transform.position.x + transform.position.y) % 2 == 0)
            isWhite = false;
        else
            isWhite = true;
    }
    public void ActivateEffect(ChessPiece piece)
    {
        this.piece = piece;
        onStep();
    }
}