﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public enum CardMode { small, enlarging, big, downscaling};
public abstract class BaseCard : MonoBehaviour {

    private CardMode mode;

    [Range(1, 20)]
    public int manaCost;
    protected GameManager manager;
    public Text manaCostIndicator;
    public Text description;

    private float enlargeScale = 0;

    protected List<GameObject> indicators = new List<GameObject>();

    public void FixedUpdate()
    {
        StartCoroutine(DownscaleCardImage());
    }

    public abstract void ActivateEffect(GameManager manager);
    public void MoveToGraveyard()
    {
        manager.GetPlayer().hand.Remove(this.gameObject);
        this.gameObject.SetActive(false);
        manager.GetPlayer().RenderHand();
    }
    public GameObject Copy()
    {
        System.Type type = this.GetType();
        BaseCard card = Instantiate(this);
        card.gameObject.SetActive(false);

        return card.gameObject;   
    }

    public IEnumerator EnlargeCardImage()
    {
        if (mode != CardMode.big && mode != CardMode.enlarging)
        {
            mode = CardMode.enlarging;
            while (enlargeScale < 1.7f && (mode == CardMode.enlarging || mode == CardMode.small))
            {
                enlargeScale += 0.1f;
                //transform.localScale += new Vector3(0.15f, 0.21f, 0.1f);
                this.transform.Find("Canvas").transform.localScale += new Vector3(0.1f, 0.1f, 0);
                this.transform.Find("Canvas").transform.position += new Vector3(0, 0.1f, -0.1f);
                yield return new WaitForSeconds(0);
            }
            if (enlargeScale == 1.7f)
                mode = CardMode.big;
        }
    }
    public IEnumerator DownscaleCardImage()
    {
        if (mode != CardMode.small && mode != CardMode.downscaling)
        {
            mode = CardMode.downscaling;
            while (enlargeScale > 0.1f && (mode == CardMode.downscaling || mode == CardMode.big))
            {
                enlargeScale -= 0.1f;
                //transform.localScale -= new Vector3(0.15f, 0.21f, 0.1f);
                this.transform.Find("Canvas").transform.localScale -= new Vector3(0.1f, 0.1f, 0);
                this.transform.Find("Canvas").transform.position -= new Vector3(0, 0.1f, -0.1f);
                yield return new WaitForSeconds(0);
            }
            if (enlargeScale == 0.1f)
                mode = CardMode.small;
        }
    }

    public virtual void ClearIndicator()
    {
        try
        {
            foreach (GameObject obj in indicators)
                Destroy(obj);
        }
        catch (System.NullReferenceException) { }
    }

    public abstract void CancelCardUse();
    public void CancelCardUse(RaycastHit hit)
    {
        CancelCardUse();
    }
}
